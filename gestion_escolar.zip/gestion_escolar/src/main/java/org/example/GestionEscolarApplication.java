package org.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionEscolarApplication {
    public static void main(String[] args) {
        SpringApplication.run(GestionEscolarApplication.class, args);
    }
}